#!/usr/bin/env bash
# Usage: ./push.sh https://github.com/<you>/<repo>.git
set -e
git init -b main
git add .
git commit -m "Initial commit"
git remote add origin "$1"
git push -u origin main
